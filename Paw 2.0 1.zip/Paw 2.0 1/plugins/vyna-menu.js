/* Owner: Ytb Vynα Vαlerié.i */
/* wa.me/6282389924037*/



let axios = require('axios')

let handler = async (m, {
	conn
}) => {
	let user = global.db.data.users[m.sender]
	let name = conn.getName(m.sender)
	let date = new Date().toLocaleDateString('en-US', {timeZone: 'Asia/Jakarta'})
	let time = new Date().toLocaleTimeString('en-US', {timeZone: 'Asia/Jakarta', hour: 'numeric', minute: 'numeric', hour12: true})
	let version = require('../package.json').version
	let author = require('../package.json').author.name
	let greeting = ''

	if (new Date().getHours() >= 0 && new Date().getHours() < 4) {
		greeting = '👋 Selamat Malam Kak'
	} else if (new Date().getHours() >= 4 && new Date().getHours() < 12) {
		greeting = '👋 Selamat Pagi Kak'
	} else if (new Date().getHours() >= 12 && new Date().getHours() < 18) {
		greeting = '👋 Selamat Sore Kak'
	} else if (new Date().getHours() >= 18 && new Date().getHours() < 24) {
		greeting = '👋 Selamat Malam Kak'
	}
	let mainmenu = `${greeting} *@${user.name}*, *Paw 2.0 Adalah Project Paw* Kamu Dapat Menggunakan Fitur-fitur Dari Paw.

╭─ •  *「 Paw 2.0 」*
│  ◦  Waktu : *${time}*
│  ◦  Tanggal : *${date}*
│  ◦  Versi : *2.0*
│  ◦  Author : *Rerey*
│  ◦  Prefix :  *.*
│  ◦  Semua Menu : *.allmenu*
│  ◦  Tentang : *.about*
╰──── •`

	let thumbnailUrl = "https://link.sazumiviki.me/2OD86o"
	let sourceUrl = "https://reret.xyz"

	conn.reply(m.chat, mainmenu, m, {
		contextInfo: {
			externalAdReply: {
				title: `Paw 20`,
				body: "Haloo, Perkenalkan Paw 2.0",
				thumbnailUrl: thumbnailUrl,
				sourceUrl: sourceUrl,
				mediaType: 1,
				renderLargerThumbnail: true
			}
		}
	})

	let songUrl = 'https://e.top4top.io/m_2703kkbxo1.mp3'
	let res2 = await axios.get(songUrl, {
		responseType: 'arraybuffer'
	})
	await conn.sendFile(m.chat, Buffer.from(res2.data), 'song.mp3', '', m)
}

handler.command = /^menu$/i
handler.help = ['menu']
handler.tags = ['main']
handler.register = true
handler.limit = true

module.exports = handler